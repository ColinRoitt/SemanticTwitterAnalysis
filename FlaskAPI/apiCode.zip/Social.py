import twitter
import time
import json


class Social:
    def __init__(self, para):
        self.dbObj = para[0]
        self.ml = para[1]
        self.api = twitter.Api(
            consumer_key='Mhza8IeYqeLY0ysePOy3gqG0R',
            consumer_secret='8XBsGVhkCgeOBEe9sRveHFPYZ0aU84aQokfJbFCLUV24SqAira',
            access_token_key='342769171-yWwNZ4Cdkfs5txJHjNVLJXNMB92N2Pt61ushltAP',
            access_token_secret='pmf7kHW2fmzA27cuHiWxBChgjei36P36MqPYwDfY0aBqn'
        )

    # GET
    def getTweets(self, PID):
        search = self.dbObj.getSearch(PID)[0][0].decode('utf-8')
        count = 1
        data = self.api.GetSearch(
            raw_query='q=' + search + '&'
            'count='+str(count)+'&'
            'lang=en&'
            'tweet_mode=extended'
        )
        if len(data) > 0:
            tweet = data[0]
            returnData = []
            # print(tweet['id_str'])
            if(not self.dbObj.tweetIsSaved(tweet.id_str)):
                tweetP = {
                    'text': tweet.full_text,
                    'hashtags': len(tweet.hashtags),
                    'mentions': len(tweet.user_mentions),
                    'likes': tweet.favorite_count,
                    'retweets': tweet.retweet_count
                }
                sentiment = self.ml.classify(tweetP)
                certainty = round(sentiment * 100, 0)
                date = time.strftime('%Y-%m-%d')
                self.dbObj.addTweet(
                    tweet.id_str, PID, tweet.full_text, str(sentiment), certainty, date)
                returnData = [tweet.id_str, PID, tweet.full_text,
                              str(sentiment), certainty, date]
            return json.dumps(returnData)
        else:
            return 'No Tweets Found'
